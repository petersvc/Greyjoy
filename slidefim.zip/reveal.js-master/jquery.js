$(document).ready(){
  $('.um_mapa').click(){
    $(this).hide(700);
  }
}
